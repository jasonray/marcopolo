BEGIN
   utconfig.setdir ('d:\openoracle\utplsql\examples');
   utconfig.showconfig;
END;
/


