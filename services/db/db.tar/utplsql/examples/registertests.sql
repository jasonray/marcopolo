BEGIN
   utplsql.trc;
   utconfig.registertest (TRUE );
   utplsql.test ('betwnstr');
END;
