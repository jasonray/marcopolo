====================================================================
Welcome to utPLSQL, the unit testing framework for PL/SQL
====================================================================

Copyright (c) 2000-2005, 2014 Steven Feuerstein and the utPLSQL Project

You have downloaded utPLSQL. 

It is not warranted to be free of bugs. 

Use it at your own risk (but, believe me, there's nothing very risky about it).

TO INSTALL

1. Unzip the software into the directory of your choice. It will create three 
sub-directories: Code, Examples and Doc.

2. Open the Doc/index.html file and follow instructions in the Getting Started 
document for either installing or upgrading utPLSQL.

TO USE

Review the on-line documentation. Start with Getting Started, then check out
Build Test Packages and dip into the User Guide as needed. 

Any questions? Go to the utPLSQL Support page at 

https://sourceforge.net/projects/utplsql/support

and let us know about it.

  
Thanks, 
Steven Feuerstein

$Id: readme.txt 166 2014-05-04 10:44:45Z p72endragon $
